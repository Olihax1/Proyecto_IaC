import json
import os
import logging

logging.basicConfig(level=os.getenv("NIVEL_LOG", "INFO"))
logger = logging.getLogger("compensacion")

def handler(evento, contexto):
    # Log entrada
    logger.info("evento_sqs_recibido", extra={"registros": len(evento.get("Records", []))})

    for registro in evento.get("Records", []):
        cuerpo = registro.get("body", "{}")
        try:
            mensaje = json.loads(cuerpo)
        except json.JSONDecodeError:
            mensaje = {"cuerpo_raw": cuerpo}

        # Acción compensatoria
        logger.warning("compensacion", extra={"mensaje": mensaje})

    return {"estado": "ok"}
